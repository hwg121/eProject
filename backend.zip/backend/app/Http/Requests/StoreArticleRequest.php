<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreArticleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            'excerpt' => 'nullable|string|max:500',
            'body' => 'required|string',
            'content' => 'nullable|string',
            'featured_image' => 'nullable|string|url',
            'cover' => 'nullable|string|url',
            'status' => 'required|in:draft,published,archived',
            'category_id' => 'nullable|exists:categories,id',
            'author_id' => 'nullable|exists:users,id',
            'published_at' => 'nullable|date',
            'views' => 'nullable|integer|min:0',
            'likes' => 'nullable|integer|min:0',
            'is_featured' => 'nullable|boolean',
            'tags' => 'nullable|array',
            'tags.*' => 'string|max:50',
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'title.required' => 'The article title is required.',
            'title.max' => 'The article title may not be greater than 255 characters.',
            'body.required' => 'The article content is required.',
            'status.required' => 'The article status is required.',
            'status.in' => 'The article status must be draft, published, or archived.',
            'category_id.exists' => 'The selected category does not exist.',
            'author_id.exists' => 'The selected author does not exist.',
            'featured_image.url' => 'The featured image must be a valid URL.',
            'cover.url' => 'The cover image must be a valid URL.',
        ];
    }
}