<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateVideoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'content' => 'nullable|string',
            'video_url' => 'sometimes|required|string|url',
            'embed_url' => 'nullable|string|url',
            'featured_image' => 'nullable|string|url',
            'cover' => 'nullable|string|url',
            'status' => 'sometimes|required|in:draft,published,archived',
            'category_id' => 'nullable|exists:categories,id',
            'instructor' => 'nullable|string|max:100',
            'duration' => 'nullable|integer|min:0',
            'difficulty' => 'nullable|in:beginner,intermediate,advanced',
            'views' => 'nullable|integer|min:0',
            'likes' => 'nullable|integer|min:0',
            'rating' => 'nullable|numeric|min:0|max:5',
            'is_featured' => 'nullable|boolean',
            'tags' => 'nullable|array',
            'tags.*' => 'string|max:50',
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'title.required' => 'The video title is required.',
            'title.max' => 'The video title may not be greater than 255 characters.',
            'video_url.required' => 'The video URL is required.',
            'video_url.url' => 'The video URL must be a valid URL.',
            'embed_url.url' => 'The embed URL must be a valid URL.',
            'status.required' => 'The video status is required.',
            'status.in' => 'The video status must be draft, published, or archived.',
            'category_id.exists' => 'The selected category does not exist.',
            'featured_image.url' => 'The featured image must be a valid URL.',
            'cover.url' => 'The cover image must be a valid URL.',
            'difficulty.in' => 'The difficulty must be beginner, intermediate, or advanced.',
            'rating.min' => 'The rating must be at least 0.',
            'rating.max' => 'The rating must not be greater than 5.',
        ];
    }
}