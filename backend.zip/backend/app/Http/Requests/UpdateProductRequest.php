<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'sometimes|required|string|max:255',
            'description' => 'sometimes|required|string|max:2000',
            'content' => 'nullable|string',
            'category' => 'sometimes|required|in:tool,book,pot,accessory,suggestion',
            'subcategory' => 'nullable|string|max:100',
            'status' => 'sometimes|required|in:published,draft,archived',
            'price' => 'nullable|numeric|min:0',
            'image' => 'nullable|string|url',
            'images_json' => 'nullable|string',
            'brand' => 'nullable|string|max:100',
            'material' => 'nullable|string|max:100',
            'size' => 'nullable|string|max:100',
            'color' => 'nullable|string|max:50',
            'is_featured' => 'nullable|boolean',
            'is_published' => 'nullable|boolean',
            'views' => 'nullable|integer|min:0',
            'likes' => 'nullable|integer|min:0',
            'rating' => 'nullable|numeric|min:0|max:5',
            'tags' => 'nullable|array',
            'tags.*' => 'string|max:50',
            'specifications' => 'nullable|array',
            'features' => 'nullable|array',
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'name.required' => 'The product name is required.',
            'name.max' => 'The product name may not be greater than 255 characters.',
            'description.required' => 'The product description is required.',
            'description.max' => 'The product description may not be greater than 2000 characters.',
            'category.required' => 'The product category is required.',
            'category.in' => 'The product category must be tool, book, pot, accessory, or suggestion.',
            'status.required' => 'The product status is required.',
            'status.in' => 'The product status must be published, draft, or archived.',
            'price.numeric' => 'The price must be a number.',
            'price.min' => 'The price must be at least 0.',
            'image.url' => 'The product image must be a valid URL.',
            'rating.min' => 'The rating must be at least 0.',
            'rating.max' => 'The rating must not be greater than 5.',
        ];
    }
}