<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreVideoRequest;
use App\Http\Requests\UpdateVideoRequest;
use App\Models\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class VideoController extends Controller
{
    public function index(Request $request)
    {
        try {
            // Check if videos table exists
            if (!Schema::hasTable('videos')) {
                return response()->json([
                    'success' => true,
                    'data' => [],
                    'meta' => [
                        'current_page' => 1,
                        'last_page' => 1,
                        'per_page' => 15,
                        'total' => 0,
                    ]
                ]);
            }

            $query = Video::query();

            // Filter by status
            if ($request->has('status')) {
                $query->where('status', $request->status);
            } else {
                $query->where('status', 'published');
            }

            // Search
            if ($request->has('search') && $request->search) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('title', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%");
                });
            }

            // Sort
            $sortBy = $request->get('sortBy', 'created_at');
            $sortOrder = $request->get('sortOrder', 'desc');
            $query->orderBy($sortBy, $sortOrder);

            // Pagination
            $perPage = min($request->get('per_page', 15), 50);
            $videos = $query->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $videos->items(),
                'meta' => [
                    'current_page' => $videos->currentPage(),
                    'last_page' => $videos->lastPage(),
                    'per_page' => $videos->perPage(),
                    'total' => $videos->total(),
                ]
            ]);
        } catch (\Exception $e) {
            // Return empty data instead of error for better frontend experience
            return response()->json([
                'success' => true,
                'data' => [],
                'meta' => [
                    'current_page' => 1,
                    'last_page' => 1,
                    'per_page' => 15,
                    'total' => 0,
                ]
            ]);
        }
    }

    public function show($id)
    {
        try {
            $video = Video::findOrFail($id);
            
            // Debug log to check video data
            \Illuminate\Support\Facades\Log::info('Video data for edit:', [
                'id' => $video->id,
                'title' => $video->title,
                'video_url' => $video->video_url,
                'link' => $video->link ?? 'NULL',
                'all_attributes' => $video->getAttributes()
            ]);
            
            return response()->json([
                'success' => true,
                'data' => $video
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error fetching video: ' . $e->getMessage()
            ], 500);
        }
    }

    public function store(StoreVideoRequest $request)
    {
        try {
            // Check if videos table exists
            if (!Schema::hasTable('videos')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Videos table does not exist'
                ], 500);
            }

            $validated = $request->validated();

            // Auto-generate embed URL from video_url if it's a YouTube URL
            if (isset($validated['video_url']) && $validated['video_url']) {
                $videoUrl = $validated['video_url'];
                $embedUrl = $this->generateEmbedUrl($videoUrl);
                if ($embedUrl) {
                    $validated['embed_url'] = $embedUrl;
                }
            }
            
            $video = Video::create($validated);
            
            return response()->json([
                'success' => true,
                'message' => 'Video created successfully',
                'data' => $video
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating video: ' . $e->getMessage()
            ], 500);
        }
    }

    public function update(UpdateVideoRequest $request, $id)
    {
        try {
            $video = Video::findOrFail($id);
            $validated = $request->validated();

            // Auto-generate embed URL from video_url if it's a YouTube URL
            if (isset($validated['video_url']) && $validated['video_url']) {
                $embedUrl = $this->generateEmbedUrl($validated['video_url']);
                if ($embedUrl) {
                    $validated['embed_url'] = $embedUrl;
                }
            }
            
            $video->update($validated);
            
            return response()->json([
                'success' => true,
                'message' => 'Video updated successfully',
                'data' => $video->fresh()
            ]);
            
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Video not found'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error updating video: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try {
            $video = Video::findOrFail($id);
            $video->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Video deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting video: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Generate embed URL from video link
     */
    private function generateEmbedUrl($link)
    {
        if (empty($link)) {
            return null;
        }
        
        // YouTube URLs
        if (strpos($link, 'youtube.com/watch?v=') !== false) {
            $videoId = explode('v=', $link)[1];
            $videoId = explode('&', $videoId)[0]; // Remove any additional parameters
            return "https://www.youtube.com/embed/{$videoId}";
        }
        
        if (strpos($link, 'youtu.be/') !== false) {
            $videoId = explode('youtu.be/', $link)[1];
            $videoId = explode('?', $videoId)[0]; // Remove any additional parameters
            return "https://www.youtube.com/embed/{$videoId}";
        }
        
        // Vimeo URLs
        if (strpos($link, 'vimeo.com/') !== false) {
            $videoId = explode('vimeo.com/', $link)[1];
            $videoId = explode('?', $videoId)[0]; // Remove any additional parameters
            return "https://player.vimeo.com/video/{$videoId}";
        }
        
        // Return null if we can't generate embed URL
        return null;
    }
}

