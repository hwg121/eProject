<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\CloudinaryService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    protected $cloudinary;

    public function __construct(CloudinaryService $cloudinary)
    {
        $this->cloudinary = $cloudinary;
    }
    /**
     * Display a listing of users.
     */
    public function index(Request $request): JsonResponse
    {
        $query = User::query();

        // Search
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('company', 'like', "%{$search}%");
            });
        }

        // Filter by role
        if ($request->has('role') && $request->role) {
            $query->where('role', $request->role);
        }

        // Filter by status
        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }

        // Sort
        $sortBy = $request->get('sortBy', 'created_at');
        $sortOrder = $request->get('sortOrder', 'desc');
        $query->orderBy($sortBy, $sortOrder);

        // Paginate
        $perPage = $request->get('per_page', 15);
        $users = $query->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $users->items(),
            'meta' => [
                'current_page' => $users->currentPage(),
                'last_page' => $users->lastPage(),
                'per_page' => $users->perPage(),
                'total' => $users->total(),
            ]
        ]);
    }

    /**
     * Store a newly created user.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
            'phone' => 'nullable|string|max:20',
            'phone_country_code' => 'nullable|string|max:5',
            'country' => 'nullable|string|max:10',
            'address' => 'nullable|string|max:500',
            'city' => 'nullable|string|max:255',
            'zip_code' => 'nullable|string|max:20',
            'role' => ['required', Rule::in(['admin', 'moderator'])],
            'status' => ['required', Rule::in(['active', 'banned'])],
            'is_banned' => 'boolean',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:3072', // 3MB max
        ]);

        // Hash password
        $validated['password'] = Hash::make($validated['password']);

        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $avatarPath = $avatar->store('avatars', 'public');
            $validated['avatar'] = $avatarPath;
        }

        $user = User::create($validated);

        return response()->json([
            'success' => true,
            'message' => 'User created successfully',
            'data' => $user
        ], 201);
    }

    /**
     * Display the specified user.
     */
    public function show(string $id): JsonResponse
    {
        $user = User::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }

    /**
     * Update the specified user.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => ['sometimes', 'email', Rule::unique('users', 'email')->ignore($id)],
            'password' => 'sometimes|string|min:8',
            'phone' => 'nullable|string|max:20',
            'state' => 'nullable|string|max:255',
            'address' => 'nullable|string|max:500',
            'city' => 'nullable|string|max:255',
            'zip_code' => 'nullable|string|max:20',
            'company' => 'nullable|string|max:255',
            'role' => ['sometimes', Rule::in(['admin', 'moderator'])],
            'status' => ['sometimes', Rule::in(['active', 'banned'])],
            'is_email_verified' => 'boolean',
            'is_banned' => 'boolean',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:3072', // 3MB max
        ]);

        // Hash password if provided
        if (isset($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        }

        // Handle avatar upload with Cloudinary
        if ($request->hasFile('avatar')) {
            try {
                // Delete old avatar from Cloudinary if exists
                if ($user->avatar_public_id) {
                    $this->cloudinary->destroy($user->avatar_public_id);
                }
                
                // Upload new avatar to Cloudinary
                $avatar = $request->file('avatar');
                $result = $this->cloudinary->uploadFeaturedImage($avatar, 'user');
                
                $validated['avatar'] = $result['secure_url'];
                $validated['avatar_public_id'] = $result['public_id'];
            } catch (\Exception $e) {
                return response()->json([
                    'success' => false,
                    'message' => 'Avatar upload failed: ' . $e->getMessage()
                ], 500);
            }
        }

        $user->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'User updated successfully',
            'data' => $user
        ]);
    }

    /**
     * Remove the specified user.
     */
    public function destroy(string $id): JsonResponse
    {
        $user = User::findOrFail($id);

        // Delete avatar if exists
        if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
            Storage::disk('public')->delete($user->avatar);
        }

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'User deleted successfully'
        ]);
    }

    /**
     * Get current user profile.
     */
    public function profile(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }

    /**
     * Get recent logs for debugging
     */
    public function getLogs(Request $request): JsonResponse
    {
        try {
            $logFile = storage_path('logs/laravel.log');
            if (!file_exists($logFile)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Log file not found'
                ]);
            }
            
            $logs = file_get_contents($logFile);
            $recentLogs = array_slice(explode("\n", $logs), -50); // Last 50 lines
            
            return response()->json([
                'success' => true,
                'logs' => $recentLogs
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error reading logs: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Test endpoint for debugging
     */
    public function testProfile(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            
            return response()->json([
                'success' => true,
                'message' => 'Test endpoint working',
                'data' => [
                    'user_id' => $user->id,
                    'request_method' => $request->method(),
                    'content_type' => $request->header('Content-Type'),
                    'request_data' => $request->all(),
                    'user_avatar' => $user->avatar,
                    'user_avatar_public_id' => $user->avatar_public_id
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Test failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update current user profile.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        try {
            $user = $request->user();

            // Debug logging
            Log::info('User profile update request', [
                'user_id' => $user->id,
                'request_data' => $request->all(),
                'has_avatar' => $request->has('avatar'),
                'avatar_value' => $request->input('avatar'),
                'has_avatar_public_id' => $request->has('avatar_public_id'),
                'avatar_public_id_value' => $request->input('avatar_public_id'),
                'request_method' => $request->method(),
                'content_type' => $request->header('Content-Type'),
                'all_inputs' => $request->all()
            ]);

            Log::info('Validating request data', [
                'user_id' => $user->id,
                'request_data' => $request->all()
            ]);

            $validated = $request->validate([
                'name' => 'sometimes|string|max:255',
                'email' => ['sometimes', 'email', Rule::unique('users', 'email')->ignore($user->id)],
                'password' => 'sometimes|string|min:8',
                'phone' => 'nullable|string|max:20',
                'phone_country_code' => 'nullable|string|max:5',
                'country' => 'nullable|string|max:10',
                'address' => 'nullable|string|max:500',
                'city' => 'nullable|string|max:255',
                'zip_code' => 'nullable|string|max:20',
                'role' => ['sometimes', Rule::in(['admin', 'moderator'])],
                'status' => ['sometimes', Rule::in(['active', 'banned'])],
                'is_banned' => 'sometimes|boolean',
                'avatar' => 'nullable|string', // Accept avatar URL from Cloudinary
                'avatar_public_id' => 'nullable|string|max:255', // Accept public_id from Cloudinary
            ]);

            // Hash password if provided
            if (isset($validated['password'])) {
                $validated['password'] = Hash::make($validated['password']);
            }

            // Avatar is already uploaded to Cloudinary, just save URL and public_id

            Log::info('Updating user profile with validated data', [
                'user_id' => $user->id,
                'validated_data' => $validated
            ]);

            $user->update($validated);

            // Refresh user data to get updated values
            $user->refresh();

            Log::info('User profile updated successfully', [
                'user_id' => $user->id,
                'avatar' => $user->avatar,
                'avatar_public_id' => $user->avatar_public_id
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Profile updated successfully',
                'data' => $user
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Profile update validation failed', [
                'user_id' => $request->user()?->id,
                'errors' => $e->errors(),
                'request_data' => $request->all()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Profile update failed', [
                'user_id' => $request->user()?->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'request_data' => $request->all()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Profile update failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Upload avatar for user (separate endpoint for admin)
     */
    public function uploadAvatar(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:3072', // 3MB max
                'model_type' => 'required|string|in:user',
                'user_id' => 'nullable|exists:users,id'
            ]);

            $user = $request->user();
            if ($validated['user_id']) {
                $user = User::findOrFail($validated['user_id']);
            }

            // Delete old avatar from Cloudinary if exists
            if ($user->avatar_public_id) {
                try {
                    $this->cloudinary->destroy($user->avatar_public_id);
                } catch (\Exception $e) {
                    Log::warning('Failed to delete old avatar', [
                        'user_id' => $user->id,
                        'public_id' => $user->avatar_public_id,
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            // Upload new avatar to Cloudinary
            $avatar = $request->file('avatar');
            $result = $this->cloudinary->uploadFeaturedImage($avatar, 'user');
            
            // Update user with new avatar
            $user->update([
                'avatar' => $result['secure_url'],
                'avatar_public_id' => $result['public_id']
            ]);
            
            Log::info('Avatar uploaded to Cloudinary successfully', [
                'user_id' => $user->id,
                'avatar_url' => $result['secure_url'],
                'public_id' => $result['public_id'],
                'file_size' => $avatar->getSize(),
                'file_name' => $avatar->getClientOriginalName()
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Avatar uploaded successfully',
                'data' => [
                    'secure_url' => $result['secure_url'],
                    'public_id' => $result['public_id'],
                    'user_id' => $user->id
                ]
            ]);
        } catch (\Exception $e) {
            Log::error('Avatar upload failed', [
                'user_id' => $request->user()?->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Avatar upload failed: ' . $e->getMessage()
            ], 500);
        }
    }
}