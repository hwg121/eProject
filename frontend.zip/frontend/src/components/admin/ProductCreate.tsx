import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Save, X } from 'lucide-react';
import Card from '../UI/Card';
import ProductForm from './ProductForm';

interface Product {
  id?: string;
  name?: string;
  title?: string;
  slug?: string;
  category: 'tool' | 'book' | 'pot' | 'accessory' | 'suggestion';
  subcategory?: string;
  status: 'published' | 'draft' | 'archived';
  description: string;
  content?: string;
  tags?: string[];
  image?: string;
  link?: string;
  is_featured?: boolean;
  is_published?: boolean;
  brand?: string;
  material?: string;
  size?: string;
  color?: string;
  price?: number;
  rating?: number;
  views?: number;
  likes?: number;
  createdAt?: string;
  updatedAt?: string;
}

interface ProductCreateProps {
  categories: string[];
  onSave: (product: Partial<Product>) => void;
  onCancel: () => void;
  isDarkMode: boolean;
}

const ProductCreate: React.FC<ProductCreateProps> = ({
  categories,
  onSave,
  onCancel,
  isDarkMode
}) => {
  const [formData, setFormData] = useState<Partial<Product>>({
    title: '',
    category: 'Tool',
    status: 'draft',
    description: '',
    tags: '',
    imageUrl: '',
    link: '',
    type: 'product',
    featured: false,
    brand: '',
    material: '',
    size: '',
    color: '',
    price: 0,
    rating: 5,
    isWaterproof: false,
    isDurable: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const processedData = {
      ...formData,
      tags: formData.tags 
        ? Array.isArray(formData.tags) 
          ? formData.tags 
          : formData.tags.split(',').map((tag: string) => tag.trim())
        : [],
      rating: parseFloat(formData.rating as any) || 0,
      price: parseFloat(formData.price as any) || 0
    };
    onSave(processedData);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <motion.button
            onClick={onCancel}
            className={`p-2 rounded-lg ${
              isDarkMode 
                ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
            } transition-colors`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          <div>
            <h2 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
              Create New Product
            </h2>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Add a new product to your catalog
            </p>
          </div>
        </div>
      </div>

      {/* Form */}
      <Card className={`p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <ProductForm
          type="products"
          item={null}
          categories={['tool', 'book', 'pot', 'accessory', 'suggestion']}
          onSave={onSave}
          onCancel={onCancel}
          isDarkMode={isDarkMode}
        />
      </Card>
    </div>
  );
};

export default ProductCreate;
