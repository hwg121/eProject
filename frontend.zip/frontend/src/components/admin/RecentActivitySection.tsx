import React from 'react';
import { Activity } from 'lucide-react';
import Card from '../UI/Card';
import { ActivityItem } from '../../types/admin';

interface RecentActivitySectionProps {
  recentActivity: ActivityItem[];
  isDarkMode: boolean;
}

const RecentActivitySection: React.FC<RecentActivitySectionProps> = ({ recentActivity, isDarkMode }) => {
  return (
    <Card>
      <div className="flex items-center justify-between mb-6">
        <h3 className={`text-2xl font-bold ${isDarkMode ? 'text-emerald-100' : 'text-gray-800'}`}>
          Recent Activity
        </h3>
        <Activity className={`h-6 w-6 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-600'}`} />
      </div>
      <div className="space-y-4">
        {recentActivity.map((activity) => (
          <div key={activity.id} className={`flex items-center space-x-4 p-4 rounded-lg ${
            isDarkMode ? 'bg-gray-800/30 backdrop-blur-sm border border-gray-700/20' : 'bg-gray-50'
          }`}>
            <div className={`w-3 h-3 rounded-full ${
              activity.type === 'user' ? 'bg-blue-500' :
              activity.type === 'content' ? 'bg-green-500' :
              activity.type === 'media' ? 'bg-purple-500' : 'bg-yellow-500'
            }`} />
            <div className="flex-1">
              <p className={`font-medium ${isDarkMode ? 'text-emerald-100' : 'text-gray-800'}`}>
                {activity.action}
              </p>
              <p className={`text-sm ${isDarkMode ? 'text-emerald-300' : 'text-gray-600'}`}>
                by {activity.user} • {activity.time}
              </p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default RecentActivitySection;
